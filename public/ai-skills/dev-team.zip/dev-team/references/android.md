# Android 流程（先读 common.md）

## 阶段与产出
1. **发现**：模块结构、minSdk/targetSdk/compileSdk、AGP/Kotlin/Gradle 版本（取自清单）、UI 技术（Compose/Views/混合）、DI、导航、网络、持久化、测试框架、flavor/buildType、Gradle 任务（读脚本或 CI）。
2. **需求**：用户故事 + 验收标准；屏幕与状态清单；所需权限及系统版本差异；最低系统版本影响；前后台/配置变更/进程被杀下的预期行为；离线与弱网预期。
3. **设计**：导航变更；UiState/Event/Effect 模型；数据流 UI→ViewModel→Repository→数据源；包/模块落位；如需后端则列接口需求。
4. **实现**：数据层 → ViewModel → UI → 资源（strings/themes/drawable）→ Manifest/DI。
5. **自测**：见"验收"。
6. **交付**：按 common.md 报告格式。

## 按变更裁剪流程
- 文案、单一资源或局部修复可合并需求/设计为一张任务卡，保留实现与验收；无 UI 变化不必创建 UI 设计任务。`plan` 是可裁剪模板，manager 在 register 前同步调整任务、依赖和验收。
- 开工记录目标 module、variant、flavor/站点、源集组合与 applicationId；多品牌项目可能通过属性/环境变量切站点，不假设一定有 product flavor。命令从当前构建文件与项目约束核对，过期路径或不存在的规则文件记为未发现。
- 多站点共享代码、主题、资源或能力配置变化时，根据受影响源集挑选代表站点回归；仅构建当前站点不能证明其他源集正常。不提交本地站点切换，不为验证而改 buildSrc 或生成的注册表。

## UI：Compose vs Views
- 以项目现状为准：纯 Compose 用 Compose；纯 Views 用 XML+既有绑定方式；混合项目新界面沿用所在模块/邻近界面技术，用 ComposeView/AndroidView 互操作。不为偏好重写既有界面。
- Compose：状态提升，remember 与 rememberSaveable 区分，副作用放 LaunchedEffect/DisposableEffect，关注重组稳定性，生命周期感知地收集 Flow。
- Views：Fragment 用 viewLifecycleOwner，onDestroyView 清 binding，列表用 ListAdapter+DiffUtil。
- 必核场景：深浅色、字体缩放、不同屏幕/折叠、横竖屏、RTL（若项目支持）、TalkBack 内容描述与触控目标。

## 生命周期 / 协程 / 权限
- 状态放 ViewModel；一次性事件用项目既有机制避免重复消费；SavedStateHandle/rememberSaveable 保存轻量状态。订阅与注册成对释放。
- 协程：UI 用 viewModelScope/lifecycleScope，长任务用 WorkManager/Service，不用 GlobalScope；Dispatcher 注入；不吞 CancellationException；Flow 的 stateIn/shareIn 策略明确。
- 权限：最小化；先说明用途再请求；处理拒绝/永久拒绝/仅此次/部分授权并给降级路径与设置入口；注意随系统版本变化的权限（通知、媒体、定位、蓝牙等）。Manifest 是共享文件，单 owner。

## 验收（按能力分级，如实标注）
1. 轻量检查：diff 检查、项目既有 lint/detekt/ktlint，选择与改动相关的任务；仅文档/Skill 修改无需 Android 编译。
2. JVM 单元测试：选择受影响模块/测试类，无需设备，但仍可能依赖 SDK、JDK、Gradle 与依赖下载。缺少其中一项时报告实际完成的检查，不保证 JVM 测试可跑。
3. 仪器/UI 测试：需模拟器或真机。
4. 手动场景清单：正常/空/错误/弱网/旋转/权限拒绝/深色/大字体/进程被杀恢复。
5. 按风险追加构建：源码、资源、Manifest 或依赖变化需要时验证目标 debug APK；R8/反射、资源裁剪、签名/加固/命名相关变化用项目要求的 release 流程。是否执行编译任务遵守项目已有约束，不把模板中的“编译”当成额外授权。

**环境限制**：先检查 SDK 路径、JDK 与 Gradle 兼容、wrapper、依赖可达性、`adb devices`。缺 SDK/JDK、无设备、依赖下载失败时区分环境与代码问题，只报告能实际执行的检查；受阻的 JVM/仪器/真机验证逐项标“未验证：原因 + 命令”。不自行安装 SDK/镜像或启动模拟器（除非范围含环境搭建）；签名密钥、google-services.json、API key 不生成不提交；Release/R8 问题未构建 release 则标未验证；性能/内存/电量结论需 profiler 数据。

## 所有权与依赖
- UI（屏幕/资源/主题）、数据（repository/Room/网络模型）、构建与清单（gradle/Manifest/proguard/CI，单 owner）。
- 依赖：数据层接口/UiState 约定 → ViewModel → UI 接入（UI 布局可在 UiState 约定后与数据层并行）；Room schema 变更与迁移先于依赖新字段的 UI；依赖版本变更先于使用者。
- 同一 checkout 的 Gradle、KSP/KAPT、资源生成、baseline profile 同步与 APK 输出由单一验证 owner 串行执行。review 与 QA 可并行读代码，但不能同时触发这些共享写入；helper 的源码范围检查不覆盖构建副作用，manager 派工前必须明确。需要并行构建时用独立 worktree 并核对共享缓存/输出。
- 保留项目对 KSP 单测、Paparazzi、站点配置、baseline profile 与资源裁剪的已有约束；生成文件只通过原任务更新。验收后核对工作区，把任务变更与构建副作用分别记录，不覆盖用户改动。
